"""Independent full-cohort replay; diagnostic tie averaging never replaces frozen SHA policy."""
from pathlib import Path
import json, hashlib, collections, datetime, resource, sys
from fractions import Fraction as F
R = Path(__file__).resolve().parents[1]
D = R / 'results/vst7_forward_study'
S = R / 'results/vst7_playwright_structure_v2'
read = lambda p: json.loads(p.read_text())
summary = read(D / 'heldout_summary.json')
admission = [json.loads(x) for x in (D / 'admission_records.jsonl').read_text().splitlines()]
orig = [json.loads(x) for x in (S / 'cohort_frames.jsonl').read_text().splitlines()]
meta = read(S / 'pipeline_metadata.json')
raw = {p['id']: p for p in meta['raw']}
assert len(admission) == len(orig) == 7508
cut = 1725148800000
start = 1722470400000
end = 1727740800000
first = {}
for p in raw.values():
    first[p['head_sha']] = min(first.get(p['head_sha'], float('inf')), p['created_ms'])

def good(batch):
    a = batch['attempts']
    return bool(a) and (not batch.get('conflicts')) and (len({x['retry'] for x in a}) == len(a)) and all((type(x['retry']) is int and x['retry'] >= 0 and (x['result'] in ('pass-like', 'fail-like')) for x in a))

def y(rec):
    return int(any((x['result'] == 'pass-like' for x in rec['target_batches'][0]['attempts']))) if rec['label_observed'] else None
bykey = {x['cohort_key']: x for x in admission}
checks = collections.Counter()
for c in orig:
    a = bykey[c['cohort_key']]
    t = first[c['fullcommit']]
    phase = 'august' if start <= t < cut else 'september' if cut <= t < end else 'outside'
    assert a['phase'] == phase
    options = []
    for p in c['frames']:
        es = [e for e in c['original_events'] if raw[e['pipeline_id']]['finished_ms'] is not None and raw[e['pipeline_id']]['finished_ms'] <= p['created_ms']]
        if es:
            options.append((p['created_ms'], p['id'], p, es))
    if options:
        _, _, p, es = min(options, key=lambda z: (z[0], z[1]))
        assert a['target'] == p and a['available_original_events'] == es
        status = 'ambiguous_original_input' if any((not good(e) for e in es)) else 'already_observed_generic_mix' if any((x['result'] == 'pass-like' for e in es for x in e['attempts'])) else 'known_unresolved'
        bs = [b for b in c['validation_batches'] if b['pipeline_id'] == p['id']]
        assert a['target_batches'] == bs
        assert a['label_observed'] == (len(bs) == 1 and good(bs[0]))
        assert a['training_time_available'] == (p['finished_ms'] is not None and p['finished_ms'] <= cut)
        assert all((raw[e['pipeline_id']]['finished_ms'] <= p['created_ms'] for e in es))
        if phase == 'september':
            assert p['created_ms'] >= cut
    else:
        status = 'no_temporal_target'
        assert a['target'] is None
    assert a['input_status'] == status
    checks['full_source_context_reconstructed'] += 1
train = [a for a in admission if a['phase'] == 'august' and a['input_status'] == 'known_unresolved' and a['training_time_available'] and a['label_observed']]
test = [a for a in admission if a['phase'] == 'september']
assert not {x['fullcommit'] for x in train} & {x['fullcommit'] for x in test}
key = lambda a: (a['case'], a['environment'], a['job_name'])
hist = collections.defaultdict(list)
for a in train:
    hist[key(a)].append(y(a))
global_p = F(sum(map(y, train)) + 1, len(train) + 2)
pools = collections.defaultdict(list)
policy = {a['cohort_key']: a for a in map(json.loads, (D / 'heldout_policy_records.jsonl').read_text().splitlines())}
for a in test:
    if a['input_status'] != 'known_unresolved':
        continue
    h = hist.get(key(a), [])
    score = F(sum(h) + 1, len(h) + 2) if h else global_p
    record = policy[a['cohort_key']]
    assert str(score) == record['score_fraction']
    assert y(a) == record['Y_generic_expectation_match']
    pools[a['target']['id']].append((score, a))
    checks['scores_and_labels_reconstructed'] += 1
out = []
signatures = []
for q, claimed in zip((F(1, 10), F(1, 4), F(1, 2)), summary['results']):
    low = F(0)
    high = F(0)
    tie_low = F(0)
    tie_high = F(0)
    offered = 0
    warm_known = F(0)
    cold_known = F(0)
    boundary_pools = 0
    for pid, pool in pools.items():
        n = len(pool)
        b = int(q * n)
        rate = F(b, n)
        ordered = sorted(pool, key=lambda sa: (-sa[0], hashlib.sha256(sa[1]['cohort_key'].encode()).hexdigest()))
        chosen = {a['cohort_key'] for _, a in ordered[:b]}
        offered += b
        for score, a in pool:
            selected = a['cohort_key'] in chosen
            assert policy[a['cohort_key']]['selected'][str(q)] == selected
            coef = F(int(selected)) - rate
            v = y(a)
            if v is None:
                low += min(coef, 0)
                high += max(coef, 0)
            else:
                low += coef * v
                high += coef * v
                if hist.get(key(a), []):
                    warm_known += coef * v
                else:
                    cold_known += coef * v
        score_counts = collections.Counter((s for s, a in pool))
        weights = {}
        remaining = b
        for score in sorted(score_counts, reverse=True):
            m = score_counts[score]
            weights[score] = F(min(max(remaining, 0), m), m)
            remaining -= m
        if any((F(0) < w < F(1) for w in weights.values())):
            boundary_pools += 1
        for score, a in pool:
            coef = weights[score] - rate
            v = y(a)
            if v is None:
                tie_low += min(coef, 0)
                tie_high += max(coef, 0)
            else:
                tie_low += coef * v
                tie_high += coef * v
    assert [str(low), str(high)] == claimed['sharp_paired_difference_exact']
    assert offered == claimed['offered_test_frame_packages']
    out.append({'budget': str(q), 'frozen_SHA_policy_count_bounds': [str(low), str(high)], 'reproduced_exact': True, 'diagnostic_post_outcome_tie_average_count_bounds': [str(tie_low), str(tie_high)], 'diagnostic_post_outcome_tie_average_float': [float(tie_low), float(tie_high)], 'frozen_known_label_difference_by_history_support': {'seen_training_key': str(warm_known), 'cold_start': str(cold_known)}, 'boundary_tie_workflows': boundary_pools})
result = {'status': 'PASS', 'checks': dict(checks), 'chronology': 'All training target workflow updated_at <= Sep1; disjoint full commits; all selected original workflows updated_at <= target creation', 'training': {'n': len(train), 'distinct_history_keys': len(hist), 'generic_matches': sum(map(y, train))}, 'results': out, 'diagnostic_scope': 'Tie-average computed after frozen policy results, diagnostic only; fixed superiority criterion not changed'}
p = R / 'reproduced/chronology.json'
assert not p.exists()
p.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
