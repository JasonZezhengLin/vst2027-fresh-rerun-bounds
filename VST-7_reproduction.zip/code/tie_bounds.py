"""Post-primary decomposition and full fixed-score tie-rule identification; preserve primary SHA policy."""
from pathlib import Path
from fractions import Fraction as F
import json, hashlib, collections, itertools, datetime
R = Path(__file__).resolve().parents[1]
D = R / 'results/vst7_forward_study'
O = R / 'reproduced/tie_bounds'
O.mkdir(exist_ok=True)
protocol = {'primary_unchanged': True, 'rule_class': 'All deterministic complete cohort-key orders preserving fixed historical scores; within each target workflow only the boundary equal-score block is free. Distinct cohort keys are disjoint across workflow pools, so any per-pool permitted order can be embedded in a fixed order. Endpoint witnesses optimize over this class and unknown labels, not a deployable outcome-aware policy.', 'unknown_labels': 'All70 independently unrestricted binary expectation-match labels; no iid or future risk claim', 'budgets': ['1/10', '1/4', '1/2'], 'decomposition': 'Fixed frozen SHA policy: additive known/missing coefficient contributions by seen-history vs cold-start. Full-rule bounds jointly optimize boundary selection and missing outcomes.'}
(O / 'protocol.json').write_text(json.dumps(protocol, indent=2) + '\n')
rows = [json.loads(s) for s in (D / 'heldout_policy_records.jsonl').read_text().splitlines()]
pools = collections.defaultdict(list)
for r in rows:
    if r['input_status'] == 'known_unresolved':
        pools[r['target_pipeline_id']].append(r)

def optimize(pool, b, maximize):
    n = len(pool)
    rate = F(b, n)
    ss = sorted({F(r['score_fraction']) for r in pool}, reverse=True)
    mandatory = []
    boundary = []
    k = 0
    for score in ss:
        block = [r for r in pool if F(r['score_fraction']) == score]
        if len(mandatory) + len(block) <= b:
            mandatory += block
        else:
            boundary = block
            k = b - len(mandatory)
            break
    selected = {r['cohort_key'] for r in mandatory}
    delta = []
    for r in boundary:
        y = r['Y_generic_expectation_match']
        cost = F(y) if y is not None else 1 - rate if maximize else rate
        delta.append((cost, r['cohort_key']))
    delta.sort(key=lambda z: (-z[0] if maximize else z[0], z[1]))
    selected.update((key for _, key in delta[:k]))
    assert len(selected) == b
    total = F(0)
    unknown = {}
    parts = collections.defaultdict(F)
    for r in pool:
        h = r['cohort_key'] in selected
        c = F(int(h)) - rate
        y = r['Y_generic_expectation_match']
        group = 'seen' if r['training_context_n'] else 'cold'
        kind = 'known' if y is not None else 'unknown'
        if y is None:
            y = int(c > 0) if maximize else int(c < 0)
            unknown[r['cohort_key']] = y
        total += c * y
        parts[group + '_' + kind] += c * y
    return (total, {'selected': sorted(selected), 'unknown_assignment': unknown, 'boundary_size': len(boundary), 'boundary_selected': k, 'contribution_parts': {k: str(v) for k, v in parts.items()}})
checks = 0
for n in range(1, 5):
    for breaks in itertools.product((0, 1), repeat=n - 1):
        scores = [F(n)]
        scores += [scores[-1] if False else F(0)] * (n - 1)
        current = n
        scores = [F(current)]
        for br in breaks:
            current -= br
            scores.append(F(current))
        for values in itertools.product((0, 1, None), repeat=n):
            pool = [{'cohort_key': str(i), 'score_fraction': str(scores[i]), 'Y_generic_expectation_match': values[i], 'training_context_n': 0} for i in range(n)]
            for b in range(n + 1):
                feasible = []
                for chosen in itertools.combinations(range(n), b):
                    cs = set(chosen)
                    if any((scores[i] < scores[j] for i in cs for j in set(range(n)) - cs)):
                        continue
                    missing = [i for i, y in enumerate(values) if y is None]
                    for yy in itertools.product((0, 1), repeat=len(missing)):
                        v = list(values)
                        for i, y in zip(missing, yy):
                            v[i] = y
                        feasible.append(sum(((F(int(i in cs)) - F(b, n)) * v[i] for i in range(n))))
                lo, _ = optimize(pool, b, False)
                hi, _ = optimize(pool, b, True)
                assert (lo, hi) == (min(feasible), max(feasible))
                checks += 1
results = []
witnesses = []
for q in map(F, protocol['budgets']):
    fixed = collections.defaultdict(F)
    lo = F(0)
    hi = F(0)
    budget = 0
    free = 0
    for pid, pool in pools.items():
        n = len(pool)
        b = int(q * n)
        budget += b
        rate = F(b, n)
        for r in pool:
            c = F(int(r['selected'][str(q)])) - rate
            y = r['Y_generic_expectation_match']
            group = 'seen' if r['training_context_n'] else 'cold'
            if y is None:
                fixed[group + '_missing_lower'] += min(c, 0)
                fixed[group + '_missing_upper'] += max(c, 0)
            else:
                fixed[group + '_known'] += c * y
        l, lw = optimize(pool, b, False)
        h, hw = optimize(pool, b, True)
        lo += l
        hi += h
        free += 0 < lw['boundary_selected'] < lw['boundary_size']
        witnesses.append({'budget': str(q), 'workflow': pid, 'pool_n': n, 'selected_b': b, 'lower': str(l), 'upper': str(h), 'lower_witness': lw, 'upper_witness': hw})
    fl = sum((fixed[g + '_known'] + fixed[g + '_missing_lower'] for g in ['seen', 'cold']))
    fh = sum((fixed[g + '_known'] + fixed[g + '_missing_upper'] for g in ['seen', 'cold']))
    primary = json.loads((D / 'heldout_summary.json').read_text())
    claim = next((x for x in primary['results'] if x['budget_fraction'] == str(q)))
    assert [str(fl), str(fh)] == claim['sharp_paired_difference_exact']
    results.append({'budget': str(q), 'offered': budget, 'fixed_SHA_decomposition_exact': {k: str(v) for k, v in fixed.items()}, 'fixed_SHA_bounds': [float(fl), float(fh)], 'full_allowed_tie_plus_unknown_exact': [str(lo), str(hi)], 'full_allowed_tie_plus_unknown_bounds': [float(lo), float(hi)], 'workflows_with_free_boundary': free})
summary = {'all_primary_bounds_reproduced': True, 'exhaustive_small_configurations': checks, 'results': results, 'rule_class': protocol['rule_class']}
(O / 'witnesses.json').write_text(json.dumps(witnesses, indent=2) + '\n')
(O / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary, indent=2))
