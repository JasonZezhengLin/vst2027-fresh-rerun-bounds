from pathlib import Path
import json,runpy
R=Path(__file__).resolve().parent;(R/'reproduced').mkdir(exist_ok=False)
runpy.run_path(str(R/'code/chronology.py'),run_name='__main__');runpy.run_path(str(R/'code/tie_bounds.py'),run_name='__main__')
out=json.loads((R/'reproduced/tie_bounds/summary.json').read_text());assert out['results']==json.loads((R/'data/expected_tie_results.json').read_text());assert out['exhaustive_small_configurations']==3732
print(json.dumps({'result':'PASS','source_contexts_reconstructed':7508,'exhaustive_tie_controls':3732,'budgets':3}),flush=True)
